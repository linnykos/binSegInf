##' Synopsis: noise-added saturated inference, for fused lasso or binary
##' segmentation (really, any method that creates a valid polyhedron and has $cp
##' and $cp.sign)
randomize_addnoise_old <- function(y, sigma, sigma.add, v, orig.fudged.poly=NULL,
                               numSteps=NA, numIS, bits=50,
                               orig.fudged.obj = NULL, ic.poly=NULL,
                               max.numIS=2000,
                               inference.type = c("rows", "pre-multiply"),
                               verbose=FALSE){

    ## New: Get many fudged TG statistics.
    inference.type = match.arg(inference.type)
    done=FALSE
    pvs = c()
    denoms = c()
    if(sigma.add==0) numIS=1

    ## Do importance sampling until you have some number of variation..
    while(!done){
        inner.tgs = sapply(1:numIS, function(isim){
            if(verbose) printprogress(isim, numIS, "importance sampling replicate")

            new.noise = rnorm(length(y),0,sigma.add)
            if(inference.type=="rows"){

                ## If applicable,append IC poly to the original poly
                if(is.null(ic.poly)){
                    poly = orig.fudged.poly
                } else {
                    poly = orig.fudged.poly
                    poly$gamma = rbind(poly$gamma, ic.poly$gamma)
                    poly$u = c(poly$u, ic.poly$u)
                }
                obj.new = partition_TG(y=y, poly=poly, shift=new.noise,
                                       v=v, sigma=sqrt(sigma^2), bits=bits)
            } else if (inference.type=="pre-multiply"){
                premult = polyhedra.bsFs(orig.fudged.obj,
                                         inference.type="pre-multiply",
                                         new.noise=new.noise, v=v,
                                         numSteps=numSteps, y=y)
                ## Append IC stopping to Gy, Gv, Gw
                if(!is.null(ic.poly)){
                    ic.Gy = as.numeric(ic.poly$gamma%*%y)
                    ic.Gv = as.numeric(ic.poly$gamma%*%v)
                    ic.Gw = as.numeric(ic.poly$gamma%*%new.noise)
                    premult$Gy = c(premult$Gy, ic.Gy)
                    premult$Gv = c(premult$Gv, ic.Gv)
                    premult$Gw = c(premult$Gw, ic.Gw)
                    premult$u = c(premult$u, ic.poly$u)
                }
                obj.new = poly_pval_from_inner_products(Gy=premult$Gy,
                                                        Gv=premult$Gv, v=v, y=y,
                                                        sigma=sigma,
                                                        u=premult$u - premult$Gw,
                                                        bits=bits)
                pv = obj.new$pv
                if(is.nan(obj.new$pv)) obj.new$pv=0 ## temporary fix

            } else {
                stop("inference type not recognized!")
            }
            ## Handle boundary cases
            pv.new = obj.new$pv
            weight.new = obj.new$denom

            ## Handle boundary cases
            if(is.nan(pv.new)) return(c(0,0)) ## Actually not calculable
            if(pv.new>1|pv.new<0)  browser() ## Not sure why this would happen, but anyway!
            if(weight.new<0 | weight.new>1) weight.new=0 ## Nomass problem is to be caught here.
            return(c(pv.new, weight.new))
        })

        rownames(inner.tgs) = c("pv", "denom")
        new.pvs = inner.tgs["pv",]
        new.denoms = inner.tgs["denom",]
        pvs = c(pvs,new.pvs)
        denoms = c(denoms,new.denoms)

        ## increase numIS
        numIS = round(numIS*1.5)

        ## Check if all pvalues are the same, and if so sample more.
        enough.things = (sigma.add==0 | any(pvs!=pvs[1]) | sum(denoms==1)>10) ## Last part
                                                               ## added because
                                                               ## sometimes
                                                               ## there is no
                                                               ## variation but
                                                               ## all denoms are
                                                               ## 1.
        print(rbind(pvs,denoms))
        reached.limit = (numIS > max.numIS)
        if(reached.limit | enough.things){ done = TRUE }
    }

    ## Calculate randomized TG statistic
    pv = sum(pvs*denoms)/sum(denoms)
    return(pv)
}


##' Synopsis: randomization wrapper for WBS.
randomize_wbsfs_old <- function(v, winning.wbs.obj, numIS = 100, sigma,
                            comprehensive=FALSE, inference.type=c("rows", "pre-multiply"),
                            cumsum.y=NULL,cumsum.v=NULL, stop.time=min(winning.wbs.obj$numSteps,
                                                                       length(winning.wbs.obj$cp)),
                            ic.poly=NULL, bits=50, max.numIS=2000,
                            improve.nomass.problem=FALSE, min.num.things=30, verbose=FALSE,
                            mc.cores=1,
                            return.more.things=FALSE,
                            warn=FALSE){

    numIntervals = winning.wbs.obj$numIntervals
    numSteps = winning.wbs.obj$numSteps

    ## Basic checks
    if(inference.type=="pre-multiply" & (is.null(cumsum.y) | is.null(cumsum.v)) ){
        stop("Provide cumulative sums of y and v, if you want to use the pre-multiply option.")
    }


    ## New PV information based on newly drawn |numIntervals| - |numSteps|
    ## intervals
    if(comprehensive) numIS=1

    done=FALSE
    parts.so.far = cbind(c(Inf,Inf))[,-1,drop=FALSE]
    rownames(parts.so.far) = c("pv", "weight")
    numIS.cumulative=0
    while(!done){
        parts = mclapply(1:numIS, function(isim){
            if(verbose) printprogress(isim+numIS.cumulative, numIS+numIS.cumulative,
                                      "importance sampling replicate")
            rerun_wbs(v=v, winning.wbs.obj=winning.wbs.obj,
                      numIntervals=numIntervals,
                      numSteps=winning.wbs.obj$numSteps,
                      sigma=sigma,
                      inference.type=inference.type,
                      cumsum.y=cumsum.y,
                      cumsum.v=cumsum.v,
                      stop.time=stop.time,
                      ic.poly=ic.poly,
                      bits=bits,
                      warn=warn)
        }, mc.cores=mc.cores)

        ## Combine the new parts with the prexisting.
        parts = t(do.call(rbind,parts)) ## Not ideal but works for now
        parts.so.far = cbind(parts.so.far, parts)

        ## Handling the problem of p-value being NaN/0/1
        things = sum(parts.so.far["weight",]>0)
        enough.things = (things > min.num.things)
        if(!improve.nomass.problem | enough.things){
            done=TRUE
        }
        pv = sum(unlist(Map('*', parts.so.far["pv",], parts.so.far["weight",])))/sum(unlist(parts.so.far["weight",]))
        ## numIS = numIS + numIS
        numIS.cumulative = numIS.cumulative + numIS

        ## cat(fill=TRUE)
        ## printf("things is %d", things)
        ## printf("numIS is %f", numIS)

        if(numIS > max.numIS) done=TRUE
    }

    ## Return more information to parse
    if(return.more.things){
        return(list(things=things, min.num.things=min.num.things, numIS.cumulative=numIS.cumulative,
                    parts.so.far=parts.so.far, pv=pv, sigma=sigma, v=v))
                    ## winning.wbs.obj=winning.wbs.obj))
    } else {
        return(pv)
    }
}
