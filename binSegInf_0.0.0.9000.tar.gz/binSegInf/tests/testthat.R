library(testthat)
library(binSegInf)

test_check("binSegInf")
