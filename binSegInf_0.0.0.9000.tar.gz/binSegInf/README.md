[![Build Status](https://travis-ci.org/linnylin92/binSegInf.svg?branch=master)](https://travis-ci.org/linnylin92/binSegInf)
[![codecov](https://codecov.io/gh/linnylin92/binSegInf/branch/master/graph/badge.svg)](https://codecov.io/gh/linnylin92/binSegInf)
